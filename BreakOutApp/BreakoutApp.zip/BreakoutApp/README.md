# Breakout

Creates a GUI where a user can input their information and set the time interval of their reminders to drink water and stretch.

Tkinter and PySimpleGUI are needed for GUI use.
