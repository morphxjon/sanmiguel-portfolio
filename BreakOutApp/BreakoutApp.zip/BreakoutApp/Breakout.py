import PySimpleGUI as sg
import time

choices = ('seconds', 'minutes', 'hours')

layout = [    [sg.Text("Please enter your login information")],
              [sg.Text('Username: '), sg.InputText()],
              [sg.Text('Password: '), sg.InputText()],
              [sg.Text('First Name: '), sg.InputText()],
              [sg.Text('Company ID: '), sg.InputText()],
              [sg.Text('How often would you like to be reminded to drink water?')],
              [sg.InputText(), sg.Listbox(choices, size = (15, len(choices)), key= '-WATEROPTIONS-')],
              [sg.Text('How often would you like to be reminded to stretch?')],
              [sg.InputText(), sg.Listbox(choices, size = (15, len(choices)), key= '-STRETCHOPTIONS-')],
              [sg.Button('Continue'), sg.Button('Cancel')]]

#create window
window = sg.Window('Reminder Application', layout).Finalize()

# Create an event loop
while True:
    event, values = window.read()
    # End program if user closes window or
    # presses the OK button
    if event in (None, 'Cancel'):
        break
    if event == 'Continue':
        sg.popup(f"You will be reminded to drink water every {values[4]} {values['-WATEROPTIONS-'][0]} and reminded to stretch every {values[5]} {values['-STRETCHOPTIONS-'][0]}")
        water_time = int(values[4])
        time.sleep(water_time)
        sg.popup(f"{values[2]}, you should drink water now.")
        stretch_time = int(values[5])
        time.sleep(stretch_time)
        sg.popup(f"{values[2]}, you should go stretch now.")
window.close()
